import React, { useRef } from "react";
import { Unity, useUnityContext } from "react-unity-webgl";

function App() {
  const unityRef = useRef(null);

  const handleToggleVR = () => {
    const unityContent = unityRef.current?.getUnityContent();
    if (
      unityContent &&
      unityContent.unityInstance &&
      unityContent.unityInstance.Module
    ) {
      unityContent.unityInstance.Module.WebXR.toggleVR();
    } else {
      console.error("Unity instance or Module not available.");
    }
  };
  const { unityProvider } = useUnityContext({
    loaderUrl: "/webxr2027/Build/webxr2027.loader.js",
    dataUrl: "/webxr2027/Build/webxr2027.data.unityweb",
    frameworkUrl: "/webxr2027/Build/webxr2027.framework.js.unityweb",
    codeUrl: "/webxr2027/Build/webxr2027.wasm.unityweb",
  });

  // We'll round the loading progression to a whole number to represent the
  // percentage of the Unity Application that has loaded.

  return (
    <div className="container">
      <h1>hi</h1>

      <Unity
        style={{ width: "2000px", height: "1000px" }}
        unityProvider={unityProvider}
      />
      <button onClick={handleToggleVR}>Toggle VR Mode</button>
    </div>
  );
}

export default App;
